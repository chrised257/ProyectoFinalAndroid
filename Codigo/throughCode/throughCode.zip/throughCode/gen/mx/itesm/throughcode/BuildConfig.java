/** Automatically generated file. DO NOT MODIFY */
package mx.itesm.throughcode;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
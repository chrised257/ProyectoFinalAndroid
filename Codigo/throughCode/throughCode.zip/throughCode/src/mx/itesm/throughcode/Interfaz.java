package mx.itesm.throughcode;



import java.util.ArrayList;
import java.util.List;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.ClipData;
import android.content.Context;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.view.DragEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.DragShadowBuilder;
import android.view.View.OnDragListener;
import android.view.View.OnTouchListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;


public class Interfaz extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_interfaz);
		
	   ListView myCommandList = (ListView)findViewById(R.id.listView1);
	   ListView listCommandsToSend = (ListView)findViewById(R.id.listCommandsToSend);
	   
	   
	   final ArrayAdapter<String> cotosend = new ArrayAdapter<String>(getApplicationContext(),
			   										R.layout.row_commands_tosend, initLinesForCommands(Interfaz.this));
	   
	   final CommandsAdapter miAdaptador = new CommandsAdapter(getApplicationContext(),
			   								R.layout.row_comandos,getDataForListView(Interfaz.this));
	 
	   //Iniciando el drag Listener
	   findViewById(R.layout.row_comandos).setOnTouchListener(new MyTouchListener());
	   
	   OnItemClickListener seleccion = new OnItemClickListener(){

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
		    	Toast.makeText(Interfaz.this,  "Comando seleccionado" , Toast.LENGTH_SHORT).show();				
			}
       	
       };
       
	   OnItemClickListener envio = new OnItemClickListener(){

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
		    	Toast.makeText(Interfaz.this, "Comando por enviar",  Toast.LENGTH_SHORT).show();				
			}
       	
       };
       
       listCommandsToSend.setOnItemClickListener(envio);
       listCommandsToSend.setAdapter(cotosend);
       
       myCommandList.setOnItemClickListener(seleccion);
       myCommandList.setAdapter(miAdaptador);
	   
	   
	    //findViewById(R.id.linear1).setOnDragListener(new MyDragListener());
	    
	}
	
	public List<String> initLinesForCommands(Context context){
		   List<String> listComandos = new ArrayList<String>();
		   			String comando;
		   			for(int i=0; i<50;i++){			//Numero de lineas aceptadas por la aplicacion: 50
		   				comando = "Comando " + i;
		   				listComandos.add(comando);
		   				
		   			}
		   			
		   return listComandos;
	}
	
	 public List<ImageView> getDataForListView(Context context)
     {
     	ImageView comando;
     	List<ImageView> listCommands = new ArrayList<ImageView>();
     	
     	comando = new ImageView(context);
     	comando.setImageResource(R.drawable.frente);
     	listCommands.add(comando);
     	
     	comando = new ImageView(context);
     	comando.setImageResource(R.drawable.atras);
     	listCommands.add(comando);
     	
     	comando = new ImageView(context);
     	comando.setImageResource(R.drawable.izquierda);
     	listCommands.add(comando);
     	
     	comando = new ImageView(context);
     	comando.setImageResource(R.drawable.derecha);
     	listCommands.add(comando);
     	
     	comando = new ImageView(context);
     	comando.setImageResource(R.drawable.led);
     	listCommands.add(comando);
     	
     	comando = new ImageView(context);
     	comando.setImageResource(R.drawable.rgb);
     	listCommands.add(comando);
     	
     	comando = new ImageView(context);
     	comando.setImageResource(R.drawable.buzzer);
     	listCommands.add(comando);
     	
     	return listCommands;
     }
	
	private final class MyTouchListener implements OnTouchListener {
		    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
		    
			public boolean onTouch(View view, MotionEvent motionEvent) {
		      if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
		        ClipData data = ClipData.newPlainText("", "");
		        DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(view);
		        view.startDrag(data, shadowBuilder, view, 0);
		        view.setVisibility(View.VISIBLE);
		        return true;
		      } 
		      
		      else {
		        return false;
		      }
		    }
		  }
	  
	  class MyDragListener implements OnDragListener {

			private int action;

		    public boolean onDrag(View v, DragEvent event) {
		      action = event.getAction();
		      switch (action) {
		      case DragEvent.ACTION_DRAG_STARTED:
		        // No hacer nada.
		        break;
		    /*  case DragEvent.ACTION_DRAG_ENTERED:
		        v.setBackgroundDrawable(enterShape);
		        break;
		      case DragEvent.ACTION_DRAG_EXITED:
		        v.setBackgroundDrawable(normalShape);
		        break;*/
		      case DragEvent.ACTION_DROP:
		        // Dropped, reassign View to ViewGroup
		        View view = (View) event.getLocalState();
		        //ViewGroup owner = (ViewGroup) view.getParent();
		        //owner.removeView(view);
		        ListView container = (ListView) v;
		        
		        ImageView oldView = (ImageView) view;
		        ImageView newView = new ImageView(getApplicationContext());
		        newView.setImageBitmap(((BitmapDrawable) oldView.getDrawable()).getBitmap());
		        
		        container.addView(newView);
		        view.setVisibility(View.VISIBLE);
		        
		        
		        break;
		     /* case DragEvent.ACTION_DRAG_ENDED:
		        v.setBackgroundDrawable(normalShape);*/
		      default:
		        break;
		      }
		      return true;
		    }
		  }
	  
	  /*PARA GENERAR EL MENU DE GUARDAR Y ABRIR*/
	  public boolean onCreateOptionsMenu(Menu menu)
	    {
	    	MenuInflater menuInflater = getMenuInflater();
	    	menuInflater.inflate(R.menu.menu_dispositivos,menu);
	    	return true;
	    }
	  
	  /*CUANDO ES SELECCIONADO CADA OPCION DE MENU*/
	  public boolean onOptionsItemSelected(MenuItem item)
	    {
	    	//Log.e("onOptionSelected",item.toString());
	    	switch(item.getItemId())
	    	{
	    	   case R.id.open:
	    		   Toast.makeText(Interfaz.this,"Abriendo...", Toast.LENGTH_SHORT).show();
	    		return true;
	    		
	    	   case R.id.save:
	    		   Toast.makeText(Interfaz.this,"Guardando...", Toast.LENGTH_SHORT).show();
	    		   return true;
	    	default:
	    		return super.onOptionsItemSelected(item);
	    	}
	    }
}

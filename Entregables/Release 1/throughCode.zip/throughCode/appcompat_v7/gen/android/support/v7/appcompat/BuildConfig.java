/** Automatically generated file. DO NOT MODIFY */
package android.support.v7.appcompat;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}